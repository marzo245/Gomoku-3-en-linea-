package dominio;

public class MaquinaMiedosaPlayer extends Player {
    
    public MaquinaMiedosaPlayer(String nombre, String color) {
        super(nombre, color);
    }

}