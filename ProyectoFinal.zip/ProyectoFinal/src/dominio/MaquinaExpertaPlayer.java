package dominio;

public class MaquinaExpertaPlayer extends Player {
    public MaquinaExpertaPlayer(String name, String color) {
        super(name, color);
    }

}