package dominio;

public class PiedraPesada extends Piedra {
    public PiedraPesada() {
        super();
        super.vida = -1;
    }

    public void setVida(int a) {
        super.vida = -1;
    }

    public void ronda() {
    }
}