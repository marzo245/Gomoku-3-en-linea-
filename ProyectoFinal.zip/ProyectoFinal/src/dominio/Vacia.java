package dominio;

public class Vacia extends Celda {
    public void actuando(int row, int col) {
    }
}
