package dominio;

public class MaquinaAgresivaPlayer extends Player {
    public MaquinaAgresivaPlayer(String nombre, String color) {
        super(nombre, color);
    }

}